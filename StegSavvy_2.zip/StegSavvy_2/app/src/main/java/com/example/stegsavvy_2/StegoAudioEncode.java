package com.example.stegsavvy_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class StegoAudioEncode extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stego_audio_encode);
    }
}