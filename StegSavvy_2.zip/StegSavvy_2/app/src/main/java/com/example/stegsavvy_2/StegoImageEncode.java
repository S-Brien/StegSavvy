package com.example.stegsavvy_2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class StegoImageEncode extends AppCompatActivity implements TextEncodingCallback{

    private static final int = SELECT_PICTURE = 100;

    private Button pick, encode, download, logout;
    private ImageView imageView;
    private EditText message;

    private TextEncoding textEncoding;
    private ImageStego imageStego;
    private ProgressDialog save;
    private Uri filepath;

    private Bitmap ogPic;
    private Bitmap encodedPic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stego_image_encode);
    }
}